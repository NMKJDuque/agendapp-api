export const SECRET = "GDFFkaouwpoHPOyq87oD724";
export const TASK_STATUS = {
    1: 1,//'Assigned',
    2: 2,//'Progress',
    3: 3,//'Due date',
    4: 4//'Finished'
}