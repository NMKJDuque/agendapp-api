## Services Agendapp

# Autenticación
- Login
- Registro
- Autologin VS Renovacion token periodica

# Usuario
- Perfil de usuario
- Obtener la lista de todos los usuarios

# tereas
- Obtener tareas de un usuario con filtros:
[status, range-due-date, search]
- Obtener el detalle de una tarea
- Crear una tarea
- Cambiar el estado de una tarea 

## Cronjobs
- Cambiar al estado de tarea vencida