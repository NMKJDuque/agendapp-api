export default {
    DATABASE_QUERY: 'Error executing database query',
    AUTENTICATION: 'Email/password not valid',
    UNDEFINED: 'Error unknow',
    EMAIL_DUPLICATED: 'Email duplicated',
}